package com.example.euclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EuclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EuclientApplication.class, args);
	}

}
