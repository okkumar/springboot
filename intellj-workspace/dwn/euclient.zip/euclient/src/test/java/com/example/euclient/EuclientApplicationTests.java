package com.example.euclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EuclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
